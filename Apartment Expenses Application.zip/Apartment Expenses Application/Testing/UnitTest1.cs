using NUnit.Framework;

namespace Testing
{
    public class Tests
    {
       

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}