﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using System;
using System.Collections.Generic;
using System.Data;

namespace Apartment_Expenses_Application.Models
{
    public class TagDb 
    {
        static string con = "Data Source=EPINHYDW0714\\SQLEXPRESS01;Initial Catalog=Project;Integrated Security=True";
        SqlConnection connection = new SqlConnection(con);

        public List<tags> Details()
        {
            SqlCommand cmd = new SqlCommand("select * from Tags", connection);
            SqlDataReader reader = cmd.ExecuteReader();
            List<tags> users = new List<tags>();
            while (reader.Read())
            {
              tags t1= new tags();
                t1.TagID = Convert.ToInt32(reader["TagID"]);
                t1.TagName= Convert.ToString(reader["TagName"]);
                t1.Description = Convert.ToString(reader["Description"]);
                users.Add(t1);
            }
            connection.Close();
            reader.Close();
            return users;

        }
        public void Insert(tags Class1)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO tags (TagName, Description) VALUES (@TagName, @Description)", connection);
            cmd.Parameters.AddWithValue("@TagName", Class1.TagName);
            cmd.Parameters.AddWithValue("@Description", Class1.Description);
            cmd.ExecuteNonQuery();
            connection.Close();
        }


        public void Update(tags Class1)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("UPDATE tags SET TagName=@TagName, Description=@Description WHERE TagID=@TagID", connection);
            cmd.Parameters.AddWithValue("@TagID", Class1.TagID);
            cmd.Parameters.AddWithValue("@TagName", Class1.TagName);
            cmd.Parameters.AddWithValue("@Description", Class1.Description);
            cmd.ExecuteNonQuery();
            connection.Close();
        }

        public void Delete(int id)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("Delete From Tags where TagID=@id", connection);
            cmd.Parameters.AddWithValue("TagID", id);
            connection.Close();
        }
    }
}
