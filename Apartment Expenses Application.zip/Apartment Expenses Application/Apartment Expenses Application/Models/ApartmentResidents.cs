﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Apartment_Expenses_Application.Models
{
    public class ApartmentResidents
    {
        [Key]
        public int ResidentID { get; set; }
        [Required]
        public string FirstName { get; set;}
        [Required]
        public string LastName { get; set;}
        [Required]
        public int FlatNumber { get; set;}
        [Required]
        public string OwnershipType { get; set;}
        [Required]
        public int ContactNumber { get; set;}
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set;}
        [Required]
        [DataType(DataType.Date)]
        public DateTime MoveInDate { get; set;}
    }
}
