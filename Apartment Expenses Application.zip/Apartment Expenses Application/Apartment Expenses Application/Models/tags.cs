﻿using System.ComponentModel.DataAnnotations;

namespace Apartment_Expenses_Application.Models
{
    public class tags
    {
        [Key]
        public int TagID { get; set; }
        [Required]
        public string TagName { get; set; }
        [Required]
        public string Description { get; set; }
    }
}
