﻿using System.ComponentModel.DataAnnotations;

namespace Apartment_Expenses_Application.Models
{
    public class Registration
    {
        [Key]
        [Required]
        [DataType(DataType.EmailAddress)]
        public string EmailID { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
