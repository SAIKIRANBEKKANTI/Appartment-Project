﻿using System.ComponentModel.DataAnnotations;

namespace Apartment_Expenses_Application.Models
{
    public class ExpenseCategories
    {
        [Key]
        public int ExpenseCategoryID { get; set; }

        public int CategoryID { get; set;}
    }
}
