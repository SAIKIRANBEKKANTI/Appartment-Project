﻿using System.ComponentModel.DataAnnotations;

namespace Apartment_Expenses_Application.Models
{
    public class Expensetags
    {
        [Key]
        public int ExpenseTagID { get; set; }
        public int ExpenseID { get; set;}
        public int TagID { get; set;}
    }
}
