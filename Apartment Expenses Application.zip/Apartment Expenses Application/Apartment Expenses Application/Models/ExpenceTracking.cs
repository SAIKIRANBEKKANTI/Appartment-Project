﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Apartment_Expenses_Application.Models
{
    public class ExpenceTracking
    {
        [Key]
        [Required]
        public int Id { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime ExpenseDate { get; set; }

        [Required]
        public string ExpenseType { get; set; }

        [Required]
        public decimal ExpenseAmount { get; set; }

        [Required]
        public string Description { get; set; }


        [Required]
        public int ResidentID { get; set; }
    }
}
