﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Apartment_Expenses_Application.Models;

namespace Apartment_Expenses_Application.Data
{
    public class Apartment_Expenses_ApplicationContext : DbContext
    {
        public Apartment_Expenses_ApplicationContext (DbContextOptions<Apartment_Expenses_ApplicationContext> options)
            : base(options)
        {
        }

        public DbSet<Apartment_Expenses_Application.Models.Registration> Registration { get; set; }

        public DbSet<Apartment_Expenses_Application.Models.ExpenceTracking> Home { get; set; }

        public DbSet<Apartment_Expenses_Application.Models.Users> Users { get; set; }

        public DbSet<Apartment_Expenses_Application.Models.ApartmentResidents> ApartmentResidents1 { get; set; }

        public DbSet<Apartment_Expenses_Application.Models.ExpenseCategories> ExpenseCategories { get; set; }

        public DbSet<Apartment_Expenses_Application.Models.tags> tags { get; set; }

        public DbSet<Apartment_Expenses_Application.Models.Expensetags> Expensetags { get; set; }
    }
}
