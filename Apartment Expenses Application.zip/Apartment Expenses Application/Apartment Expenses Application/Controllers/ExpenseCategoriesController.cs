﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Apartment_Expenses_Application.Data;
using Apartment_Expenses_Application.Models;

namespace Apartment_Expenses_Application.Controllers
{
    public class ExpenseCategoriesController : Controller
    {
        private readonly Apartment_Expenses_ApplicationContext _context;

        public ExpenseCategoriesController(Apartment_Expenses_ApplicationContext context)
        {
            _context = context;
        }

        // GET: ExpenseCategories
        public async Task<IActionResult> Index()
        {
            return View(await _context.ExpenseCategories.ToListAsync());
        }

        // GET: ExpenseCategories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenseCategories = await _context.ExpenseCategories
                .FirstOrDefaultAsync(m => m.ExpenseCategoryID == id);
            if (expenseCategories == null)
            {
                return NotFound();
            }

            return View(expenseCategories);
        }

        // GET: ExpenseCategories/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ExpenseCategories/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ExpenseCategoryID,CategoryID")] ExpenseCategories expenseCategories)
        {
            if (ModelState.IsValid)
            {
                _context.Add(expenseCategories);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(expenseCategories);
        }

        // GET: ExpenseCategories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenseCategories = await _context.ExpenseCategories.FindAsync(id);
            if (expenseCategories == null)
            {
                return NotFound();
            }
            return View(expenseCategories);
        }

        // POST: ExpenseCategories/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ExpenseCategoryID,CategoryID")] ExpenseCategories expenseCategories)
        {
            if (id != expenseCategories.ExpenseCategoryID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(expenseCategories);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExpenseCategoriesExists(expenseCategories.ExpenseCategoryID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(expenseCategories);
        }

        // GET: ExpenseCategories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenseCategories = await _context.ExpenseCategories
                .FirstOrDefaultAsync(m => m.ExpenseCategoryID == id);
            if (expenseCategories == null)
            {
                return NotFound();
            }

            return View(expenseCategories);
        }

        // POST: ExpenseCategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var expenseCategories = await _context.ExpenseCategories.FindAsync(id);
            _context.ExpenseCategories.Remove(expenseCategories);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExpenseCategoriesExists(int id)
        {
            return _context.ExpenseCategories.Any(e => e.ExpenseCategoryID == id);
        }
    }
}
