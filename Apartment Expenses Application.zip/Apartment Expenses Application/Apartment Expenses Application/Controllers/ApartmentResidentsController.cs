﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Apartment_Expenses_Application.Data;
using Apartment_Expenses_Application.Models;

namespace Apartment_Expenses_Application.Controllers
{
    public class ApartmentResidentsController : Controller
    {
        private readonly Apartment_Expenses_ApplicationContext _context;

        public ApartmentResidentsController(Apartment_Expenses_ApplicationContext context)
        {
            _context = context;
        }

        // GET: ApartmentResidents
        public async Task<IActionResult> Index()
        {
            return View(await _context.ApartmentResidents1.ToListAsync());
        }

        // GET: ApartmentResidents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apartmentResidents = await _context.ApartmentResidents1
                .FirstOrDefaultAsync(m => m.ResidentID == id);
            if (apartmentResidents == null)
            {
                return NotFound();
            }

            return View(apartmentResidents);
        }

        // GET: ApartmentResidents/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ApartmentResidents/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ResidentID,FirstName,LastName,FlatNumber,OwnershipType,ContactNumber,Email,MoveInDate")] ApartmentResidents apartmentResidents)
        {
            if (ModelState.IsValid)
            {
                _context.Add(apartmentResidents);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(apartmentResidents);
        }

        // GET: ApartmentResidents/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apartmentResidents = await _context.ApartmentResidents1.FindAsync(id);
            if (apartmentResidents == null)
            {
                return NotFound();
            }
            return View(apartmentResidents);
        }

        // POST: ApartmentResidents/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ResidentID,FirstName,LastName,FlatNumber,OwnershipType,ContactNumber,Email,MoveInDate")] ApartmentResidents apartmentResidents)
        {
            if (id != apartmentResidents.ResidentID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(apartmentResidents);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ApartmentResidentsExists(apartmentResidents.ResidentID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(apartmentResidents);
        }

        // GET: ApartmentResidents/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apartmentResidents = await _context.ApartmentResidents1
                .FirstOrDefaultAsync(m => m.ResidentID == id);
            if (apartmentResidents == null)
            {
                return NotFound();
            }

            return View(apartmentResidents);
        }

        // POST: ApartmentResidents/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var apartmentResidents = await _context.ApartmentResidents1.FindAsync(id);
            _context.ApartmentResidents1.Remove(apartmentResidents);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ApartmentResidentsExists(int id)
        {
            return _context.ApartmentResidents1.Any(e => e.ResidentID == id);
        }
    }
}
