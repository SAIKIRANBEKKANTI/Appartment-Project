﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Apartment_Expenses_Application.Data;
using Apartment_Expenses_Application.Models;

namespace Apartment_Expenses_Application.Controllers
{
    public class ExpenceTrackingsController : Controller
    {
        private readonly Apartment_Expenses_ApplicationContext _context;

        public ExpenceTrackingsController(Apartment_Expenses_ApplicationContext context)
        {
            _context = context;
        }

        // GET: ExpenceTrackings
        public async Task<IActionResult> Index()
        {
            return View(await _context.Home.ToListAsync());
        }

        // GET: ExpenceTrackings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenceTracking = await _context.Home
                .FirstOrDefaultAsync(m => m.Id == id);
            if (expenceTracking == null)
            {
                return NotFound();
            }

            return View(expenceTracking);
        }

        // GET: ExpenceTrackings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ExpenceTrackings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ExpenseDate,ExpenseType,ExpenseAmount,Description,ResidentID")] ExpenceTracking expenceTracking)
        {
            if (ModelState.IsValid)
            {
                _context.Add(expenceTracking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(expenceTracking);
        }

        // GET: ExpenceTrackings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenceTracking = await _context.Home.FindAsync(id);
            if (expenceTracking == null)
            {
                return NotFound();
            }
            return View(expenceTracking);
        }

        // POST: ExpenceTrackings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ExpenseDate,ExpenseType,ExpenseAmount,Description,ResidentID")] ExpenceTracking expenceTracking)
        {
            if (id != expenceTracking.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(expenceTracking);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExpenceTrackingExists(expenceTracking.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(expenceTracking);
        }

        // GET: ExpenceTrackings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenceTracking = await _context.Home
                .FirstOrDefaultAsync(m => m.Id == id);
            if (expenceTracking == null)
            {
                return NotFound();
            }

            return View(expenceTracking);
        }

        // POST: ExpenceTrackings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var expenceTracking = await _context.Home.FindAsync(id);
            _context.Home.Remove(expenceTracking);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExpenceTrackingExists(int id)
        {
            return _context.Home.Any(e => e.Id == id);
        }
    }
}
