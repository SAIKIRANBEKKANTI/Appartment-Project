﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Apartment_Expenses_Application.Data;
using Apartment_Expenses_Application.Models;

namespace Apartment_Expenses_Application.Controllers
{
    [Route("Exp")]
    [ApiController]
    public class ExpenceTrackingsApiController : ControllerBase
    {
        private readonly Apartment_Expenses_ApplicationContext _context;

        public ExpenceTrackingsApiController(Apartment_Expenses_ApplicationContext context)
        {
            _context = context;
        }

        // GET: api/ExpenceTrackingsApi
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ExpenceTracking>>> GetHome()
        {
            return await _context.Home.ToListAsync();
        }

        // GET: api/ExpenceTrackingsApi/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ExpenceTracking>> GetExpenceTracking(int id)
        {
            var expenceTracking = await _context.Home.FindAsync(id);

            if (expenceTracking == null)
            {
                return NotFound();
            }

            return expenceTracking;
        }

        // PUT: api/ExpenceTrackingsApi/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutExpenceTracking(int id, ExpenceTracking expenceTracking)
        {
            if (id != expenceTracking.Id)
            {
                return BadRequest();
            }

            _context.Entry(expenceTracking).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ExpenceTrackingExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ExpenceTrackingsApi
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ExpenceTracking>> PostExpenceTracking(ExpenceTracking expenceTracking)
        {
            _context.Home.Add(expenceTracking);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetExpenceTracking", new { id = expenceTracking.Id }, expenceTracking);
        }

        // DELETE: api/ExpenceTrackingsApi/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ExpenceTracking>> DeleteExpenceTracking(int id)
        {
            var expenceTracking = await _context.Home.FindAsync(id);
            if (expenceTracking == null)
            {
                return NotFound();
            }

            _context.Home.Remove(expenceTracking);
            await _context.SaveChangesAsync();

            return expenceTracking;
        }

        private bool ExpenceTrackingExists(int id)
        {
            return _context.Home.Any(e => e.Id == id);
        }
    }
}
