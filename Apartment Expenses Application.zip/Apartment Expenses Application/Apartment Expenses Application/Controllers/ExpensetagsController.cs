﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Apartment_Expenses_Application.Data;
using Apartment_Expenses_Application.Models;

namespace Apartment_Expenses_Application.Controllers
{
    public class ExpensetagsController : Controller
    {
        private readonly Apartment_Expenses_ApplicationContext _context;

        public ExpensetagsController(Apartment_Expenses_ApplicationContext context)
        {
            _context = context;
        }

        // GET: Expensetags
        public async Task<IActionResult> Index()
        {
            return View(await _context.Expensetags.ToListAsync());
        }

        // GET: Expensetags/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expensetags = await _context.Expensetags
                .FirstOrDefaultAsync(m => m.ExpenseTagID == id);
            if (expensetags == null)
            {
                return NotFound();
            }

            return View(expensetags);
        }

        // GET: Expensetags/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Expensetags/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ExpenseTagID,ExpenseID,TagID")] Expensetags expensetags)
        {
            if (ModelState.IsValid)
            {
                _context.Add(expensetags);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(expensetags);
        }

        // GET: Expensetags/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expensetags = await _context.Expensetags.FindAsync(id);
            if (expensetags == null)
            {
                return NotFound();
            }
            return View(expensetags);
        }

        // POST: Expensetags/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ExpenseTagID,ExpenseID,TagID")] Expensetags expensetags)
        {
            if (id != expensetags.ExpenseTagID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(expensetags);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExpensetagsExists(expensetags.ExpenseTagID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(expensetags);
        }

        // GET: Expensetags/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expensetags = await _context.Expensetags
                .FirstOrDefaultAsync(m => m.ExpenseTagID == id);
            if (expensetags == null)
            {
                return NotFound();
            }

            return View(expensetags);
        }

        // POST: Expensetags/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var expensetags = await _context.Expensetags.FindAsync(id);
            _context.Expensetags.Remove(expensetags);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExpensetagsExists(int id)
        {
            return _context.Expensetags.Any(e => e.ExpenseTagID == id);
        }
    }
}
