﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;

namespace Filters_In_MVC.Filters
{
    public class ResultExecution : FilterAttribute
    {
    }
}