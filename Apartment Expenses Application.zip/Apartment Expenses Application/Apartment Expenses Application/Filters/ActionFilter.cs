﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;

namespace Filters_In_MVC.Filters
{
    public class ActionFilter : FilterAttribute, Microsoft.AspNetCore.Mvc.Filters.IActionFilter
    {

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {

        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {


        }
    }
}